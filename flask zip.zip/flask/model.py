import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from imblearn.combine import SMOTETomek
from sklearn.model_selection import train_test_split, GridSearchCV
import xgboost as xgb
import pickle

# Load data
df = pd.read_excel(r'C:\Users\admin\Desktop\churn project\E Commerce Dataset.xlsx', sheet_name='E Comm')

# Data preprocessing
df.loc[df['PreferredLoginDevice'] == 'Phone', 'PreferredLoginDevice'] = 'Mobile Phone'
df.loc[df['PreferredPaymentMode'] == 'COD', 'PreferredPaymentMode'] = 'Cash on Delivery'
df.loc[df['PreferredPaymentMode'] == 'Credit Card', 'PreferredPaymentMode'] = 'Credit Card'
df.drop('CustomerID', axis=1, inplace=True)
df.drop(['CouponUsed'], axis=1, inplace=True)

# Fill missing values
for i in df.columns:
    if df[i].dtype in ['float64', 'int64']:
        df[i] = df[i].fillna(df[i].median())
    elif df[i].dtype == 'object':
        df[i] = df[i].fillna(df[i].mode()[0])

# Encode categorical features
le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])
df['Churn'] = le.fit_transform(df['Churn'])

# One-hot encoding
df_new = pd.get_dummies(df)

# Feature and target variables
x = df_new.drop('Churn', axis=1)
y = df_new['Churn']

# Handle class imbalance
smt = SMOTETomek(random_state=42)
x_over, y_over = smt.fit_resample(x, y)

# Train-test split
x_train, x_test, y_train, y_test = train_test_split(x_over, y_over, test_size=0.3, random_state=42)

# Standardize features
num_columns = x_train.select_dtypes(include=['float64', 'int64']).columns
scaler = StandardScaler()
x_train[num_columns] = scaler.fit_transform(x_train[num_columns])
x_test[num_columns] = scaler.transform(x_test[num_columns])

# XGBoost model and hyperparameter tuning
xgb_model = xgb.XGBClassifier()

# Define the parameter grid
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [3, 5],
    'learning_rate': [0.01, 0.1],
    'subsample': [0.8, 1.0],
}

grid_search = GridSearchCV(xgb_model, param_grid, cv=5, n_jobs=-1)
grid_search.fit(x_train, y_train)

# Save the best model
best_model = grid_search.best_estimator_
with open('model.pkl', 'wb') as file:
    pickle.dump(best_model, file)

