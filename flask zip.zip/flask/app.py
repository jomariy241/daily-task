from flask import Flask, request, render_template
import numpy as np
import pickle
import pandas as pd

app = Flask(__name__)

# Load the trained model
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/')
def home():
    return render_template('index1.html')

@app.route('/predict', methods=['POST'])
def predict():
        # Extract features from form
        tenure = float(request.form['tenure'])
        preferred_login_device = request.form['preferredLoginDevice']
        city_tier = int(float(request.form['cityTier']))
        warehouse_to_home = float(request.form['warehouseToHome'])
        preferred_payment_mode = request.form['preferredPaymentMode']
        gender = (request.form['gender'])
        hour_spend_on_app = float(request.form['hourSpendOnApp'])
        number_of_device_registered = int(float(request.form['numberOfDeviceRegistered']))
        prefered_order_cat = request.form['preferedOrderCat']
        satisfaction_score = float(request.form['satisfactionScore'])
        marital_status = request.form['maritalStatus']
        number_of_address = int(float(request.form['numberOfAddress']))
        complain = int(float(request.form['complain']))
        order_amount_hike_from_last_year = float(request.form['orderAmountHikeFromLastYear'])
        order_count = int(float(request.form['orderCount']))
        day_since_last_order = int(float(request.form['daySinceLastOrder']))
        cashback_amount = float(request.form['cashbackAmount'])

        # Create a DataFrame for the input
        input_data = {
            'Tenure': [tenure],
            'CityTier': [city_tier],
            'WarehouseToHome': [warehouse_to_home],
            'Gender': [gender],
            'HourSpendOnApp': [hour_spend_on_app],
            'NumberOfDeviceRegistered': [number_of_device_registered],
            'SatisfactionScore': [satisfaction_score],
            'NumberOfAddress': [number_of_address],
            'Complain': [complain],
            'OrderAmountHikeFromlastYear': [order_amount_hike_from_last_year],
            'OrderCount': [order_count],
            'DaySinceLastOrder': [day_since_last_order],
            'CashbackAmount': [cashback_amount],
            'PreferredLoginDevice': [preferred_login_device],
            'PreferredPaymentMode': [preferred_payment_mode],
            'PreferedOrderCat': [prefered_order_cat],
            'MaritalStatus': [marital_status]
        }

        # Convert to DataFrame
        input_df = pd.DataFrame(input_data)

        # Apply one-hot encoding
        input_encoded = pd.get_dummies(input_df)

        # Add missing columns that were present during training but not in the current input
        for col in model:
            if col not in input_encoded.columns:
                input_encoded[col] = 0

        # Ensure the columns are in the same order as during training
        input_encoded = input_encoded[model]

        # Make prediction
        prediction = model.predict(input_encoded)[0]

        # Interpret prediction
        result = 'The customer is likely to churn.' if prediction == 1 else 'The customer is not likely to churn.'

        return render_template('index1.html', prediction=result)
if __name__ == '__main__':
     app.run(debug=True)